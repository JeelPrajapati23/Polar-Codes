clc;
clear;


N = 1024;
snr_db = 1;
snr = 10^(snr_db / 10);
sigma2 = 1 / (2 * snr);
m0 = 2 / sigma2;

% Gaussian Approximation function f(x)
f_func = @(x) (x < 10) .* exp(-0.4527 * x.^0.86 + 0.0218) + ...
              (x >= 10) .* (sqrt(pi ./ x) .* (1 - 10 ./ (7 * x)) .* exp(-x / 4));

% Inverse of f using interpolation
x_vals = linspace(0.01, 100, 10000);
f_vals = f_func(x_vals);
inv_f = @(y) interp1(f_vals, x_vals, y, 'linear', 'extrap');


means = m0;
stages = log2(N);

for s = 1:stages
    new_means = zeros(1, 2 * length(means));
    for i = 1:length(means)
        m = means(i);
        new_means(2*i - 1) = inv_f(1 - (1 - f_func(m))^2);
        new_means(2*i)     = 2 * m;
    end
    means = new_means;
end

Z = exp(-means / 4);


figure;
plot(1:N, Z, 'b.', 'MarkerSize', 6);
title('Bhattacharya Parameter of channels after Channel Polarization');
xlabel('Channel Index');
ylabel('Z(W)');
grid on;

Z_sorted = sort(Z);
figure;
plot(1:N, Z_sorted, 'r.-');
title('Sorted Values for Bhattacharya Parameters');
xlabel('Sorted Channel Index');
ylabel('Z(W) - Sorted');
grid on;

aa code pan akhi deje